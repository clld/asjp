
ASJP data download
==================

Data of ASJP is published under the following license:
http://creativecommons.org/licenses/by/4.0/

It should be cited as

Wichmann, Søren & Müller, André & Wett, Annkathrin & Velupillai, Viveka & Bischoffberger, Julia & Brown, Cecil H. & Holman, Eric W. & Sauppe, Sebastian & Molochieva, Zarina & Brown, Pamela & Hammarström, Harald & Belyaev, Oleg & List, Johann-Mattis & Bakker, Dik & Egorov, Dmitry & Urban, Matthias & Mailhammer, Robert & Carrizo, Agustina & Dryer, Matthew S. & Korovina, Evgenia & Beck, David & Geyer, Helen & Epps, Pattie & Grant, Anthony & Sidwell, Paul & Rama, K. Taraka & Valenzuela, Pilar & Donohue, Mark 2014.
The ASJP Database.
None: None.
(Available online at http://asjp.clld.org, Accessed on 2014-11-18.)

