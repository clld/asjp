import ez_setup
ez_setup.use_setuptools()
from setuptools import setup
setup(
    name='process_asjp',
    version='0.0.1',
    scripts=['process_asjp.py', 'ethnologue_tree.py', 'ez_setup.py'],
    package_data = {
        '': ['LICENSE','documentation/process_asjp.pdf'],
        },
    install_requires = ['BeautifulSoup>=3.1.0.1'],
    author='Paul Huff',
    author_email='paul.huff@gmail.com',
    description = 'Process_asjp is a script for generating testable subsets of ASJP data.',
    license='Apache 2.0'
    )
      
