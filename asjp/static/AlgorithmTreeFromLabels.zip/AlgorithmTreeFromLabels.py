#!/usr/bin/env python

"""
AlgorithmTreeFromLabels.py

Created by Bibiko on 2009-08-26.
Copyright (c) 2009 Hans-J. Bibiko. All rights reserved.
"""

import sys
import os
import getopt
import sets


help_message = '''
The help message goes here.
'''

argv = sys.argv

if len(argv) != 2:
	print "I do need a file name!"
	sys.exit(1)

def a():

	fileData = open(argv[1], "r")
	# fileData = open("bogus.txt", "r")

	# remember the input file name for outputting the result in FILENAME.nex
	fileName = os.path.splitext(argv[1])[0]


	# read the file content into theData - each line => row - each row array of line which is split by .
	theData = []
	for line in fileData.readlines():
		theData.append(line.rstrip("\r\n").split("."))

	# close file connection
	fileData.close()

	# get maximum depth of classification in theData
	maxDepth = 0
	for line in theData:
		if(len(line) > maxDepth):
			maxDepth = len(line)

	# fill gaps in thData with "" for simplification the code
	for line in theData:
		while(len(line) < maxDepth):
			line.append('')

	# get the lg names as array lgNames
	# set ntax to number of languages
	lgNames = []
	for lg in theData:
		lgNames.append(lg[0])
	ntax = len(lgNames)

	# how long is the longest name for output formatting?
	maxLgLength = 0
	for lg in lgNames:
		if len(lg) > maxLgLength:
			maxLgLength = len(lg)

	# matrix holds the calculated split tree infos
	matrix = []

	# init matrix
	for i in range(ntax):
		m = []
		m.append(str(i+1))
		for j in range(maxDepth-1):
			m.append("_")

		matrix.append(m)


	# go through each classification (ignore empty classification strings)
	for i in range(maxDepth)[1:]:
		aNodeList = []
		uniqueNodeList = []
		# get all node names for jth dimension
		# combine node names to ensure uniqueness from the beginning to ith element
		for j in range(ntax):
			# combine node nodes
			nodeName = ""
			for k in range(1,i+1):
				if len(theData[j][k]):
					nodeName += theData[j][k]
				else:
					nodeName = ""

			if len(nodeName):
				aNodeList.append(nodeName)

		# make an unique list of node names
		uniqueNodeList = list(set(aNodeList))

		# replace node names by numbers
		for j in range(ntax):
			# combine node nodes
			nodeName = ""
			for k in range(1,i+1):
				if len(theData[j][k]):
					nodeName += theData[j][k]
				else:
					nodeName = ""

			if len(nodeName):
				matrix[j][i] = uniqueNodeList.index(nodeName)+1

	# go through the matrix and replace a number by a 1 in a string of "000.." whereby
	# the number represents the position of the 1 in "00000" : eg  3 => 00100 , 2 => 01000
	for i in range(maxDepth):
		# first check the maximum number in each column
		max = 0
		for j in range(ntax):
			if matrix[j][i] != '_':
				if int(matrix[j][i]) > max:
					max = int(matrix[j][i])
		# make a string of max "0"s and and put a 1 at the matrix cell's position
		for j in range(ntax):
			newCell = ""
			for k in range(1,max+1):
				if matrix[j][i] == '_':
					newCell += '0'
				elif int(matrix[j][i]) == k:
					newCell += '1'
				else:
					newCell += '0'

			matrix[j][i] = str(newCell)

	# concatenate each columns of a row and ignore each element of the length 1
	# ie no information for building a tree
	for i in range(ntax):
		newRow = ""
		for j in range(maxDepth):
			if len(matrix[i][j]) > 1:
				newRow += matrix[i][j]
		matrix[i] = newRow


	# write nexus data file
	outputFileName = fileName + ".nex"
	outputFile = open(outputFileName, "w+")
	outputFile.write('#nexus')
	outputFile.write(os.linesep)
	outputFile.write(os.linesep)
	outputFile.write('BEGIN Taxa;')
	outputFile.write(os.linesep)
	outputFile.write('DIMENSIONS ntax=%d;' % ntax)
	outputFile.write(os.linesep)
	outputFile.write('TAXLABELS')
	outputFile.write(os.linesep)
	for i in range(ntax):
		outputFile.write("[%(cnt)d]  '%(lang)s'" % {'cnt': i+1, 'lang': lgNames[i] })
		outputFile.write(os.linesep)

	outputFile.write(';')
	outputFile.write(os.linesep)
	outputFile.write('END;  [TAXA]')
	outputFile.write(os.linesep)
	outputFile.write(os.linesep)
	outputFile.write('BEGIN Characters;')
	outputFile.write(os.linesep)
	outputFile.write('DIMENSIONS nchar=%d;' % len(matrix[0]))
	outputFile.write(os.linesep)
	outputFile.write('FORMAT')
	outputFile.write(os.linesep)
	outputFile.write('        missing=?')
	outputFile.write(os.linesep)
	outputFile.write('        gap=-')
	outputFile.write(os.linesep)
	outputFile.write('        symbols="0 1"')
	outputFile.write(os.linesep)
	outputFile.write('        labels')
	outputFile.write(os.linesep)
	outputFile.write('        no transpose')
	outputFile.write(os.linesep)
	outputFile.write('        no interleave')
	outputFile.write(os.linesep)
	outputFile.write(';')
	outputFile.write(os.linesep)
	outputFile.write('MATRIX')
	outputFile.write(os.linesep)
	for i in range(ntax):
		frmt = "'%%(lang)s'%%(sp)-%ds%%(data)s" % (maxLgLength - len(lgNames[i]) + 8)
		outputFile.write(frmt % {'lang': lgNames[i], 'sp': " " , 'data': matrix[i] })
		outputFile.write(os.linesep)

	outputFile.write(';')
	outputFile.write(os.linesep)
	outputFile.write('END;  [Characters]')
	outputFile.write(os.linesep)
	outputFile.write('BEGIN st_Assumptions;')
	outputFile.write(os.linesep)
	outputFile.write('        chartransform=Hamming;')
	outputFile.write(os.linesep)
	outputFile.write('        disttransform=SplitDecomposition;')
	outputFile.write(os.linesep)
	outputFile.write('        splitstransform=EqualAngle;')
	outputFile.write(os.linesep)
	outputFile.write('        SplitsPostProcess filter=dimension value=4;')
	outputFile.write(os.linesep)
	outputFile.write('        autolayoutnodelabels;')
	outputFile.write(os.linesep)
	outputFile.write('END;  [st_Assumptions]')
	outputFile.write(os.linesep)

	outputFile.close()

a()

