import re

# specify the files
megafile    = open("data.meg","r")
nexusfile   = file("data_converted.nex", "w")


print "start reading mega"
no_of_taxa=False
startItem=False
startMatrix=False
nextItem=False
r=[]
items=[]
rowIndex=0
for row in megafile:
    rowIndex= rowIndex+1
    if not no_of_taxa:
        if "No. of Taxa" in row:
            prop = row.split(":")
            no_of_taxa = int(prop[1].strip(" \n\t"))
            print "Number of Taxa: "+ str(no_of_taxa)
            startItem = True
    elif startItem and "] #" in row and not startMatrix:
        s=row.find("] #")+3
        e=row.find("{")
        item = row[s:e]
        items.append(item)
        print "Taxa "+str(len(items))+": "+item
        nextItem=True
    elif nextItem and startItem and "] #" not in row:
         startMatrix=True
         startItem=False
         matrix=[[0.000 for j in range(0,no_of_taxa)] for i in range(0,no_of_taxa)]
    elif startMatrix:
        if "[" in row and "]" in row:
            s=row.find("[")
            e=row.find("]")
            num = int(row[s+1:e].strip(" \n\t"))
            if num>0 and num<=no_of_taxa:
                values=row[e+1:].lstrip(' ')
                values=values.rstrip('\n')
                while True:
                    old=values
                    values = values.replace("  "," ")
                    if old==values:break
                values=values.rstrip('')    
                values=values.lstrip('')
                if len(values)>0:
                    values =values.split(" ")
                    for i,value in enumerate(values):
                        matrix[num-1][i]=float(int(value)/1000.0)
                        print "Value:["+str(num-1)+"]["+str(i)+"] "+str( matrix[num-1][i])
    elif "Stop" in row:           
         break
print "start writing nexus"

nexusfile.write("#nexus\n"+
                "\n")
nexusfile.write("BEGIN Taxa;\n")
nexusfile.write("DIMENSIONS ntax="+str(no_of_taxa)+";\n"
                "TAXLABELS\n"+
                "\n")
for i in range(0,no_of_taxa):
    nexusfile.write("["+str(i+1)+"] '"+items[i]+"'\n")
nexusfile.write(";\n"+
                "\n"+
                "END; [Taxa]\n"+
                "\n")
nexusfile.write("BEGIN Distances;\n"
                "DIMENSIONS ntax="+str(no_of_taxa)+";\n"+
                "FORMAT labels=left diagonal triangle=lower;\n")
nexusfile.write("MATRIX\n")
for i in range(0,len(matrix)):
    row="["+str(i+1)+"]\t'"+items[i]+"'\t"
    for j in range(0,(i+1)):
        row=row+str(matrix[i][j])+"\t"
    nexusfile.write(row+"\n")
nexusfile.write(";\n"+
                "END; [Distances]\n"+
                "\n"+
                "BEGIN st_Assumptions;\n"+
                "    disttransform=NeighborNet;\n"+
                "    splitstransform=EqualAngle;\n"+
                "    SplitsPostProcess filter=dimension value=4;\n"+
                "    autolayoutnodelabels;\n"+
                "END; [st_Assumptions]\n")
nexusfile.flush()
print "finsih converting ("+nexusfile.name+")"
